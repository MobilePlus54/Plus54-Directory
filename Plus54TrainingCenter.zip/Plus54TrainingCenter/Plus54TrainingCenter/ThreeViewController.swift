//
//  ThreeViewController.swift
//  Plus54TrainingCenter
//
//  Created by matias on 6/25/15.
//  Copyright © 2015 Plus54. All rights reserved.
//

import UIKit

class ThreeViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var tableView: UITableView!
    
    var dogDescriptions: [String] = ["The Airedale Terrier (often shortened to Airedale), also called Bingley Terrier and Waterside Terrier, is a dog breed of the terrier type that originated in the valley (dale) of the River Aire, in the West Riding of Yorkshire, England.","The American Water Spaniel.","The Andalusian hound (Spanish: podenco andaluz) is a dog breed originating in Spain, especially Andalusia. These dogs are similar to other Iberian breeds such as the Ibizan Hound, the Portuguese Podengo, the Podenco Canario and the Maneto. ","The Anglo-Français de Petite Vénerie is a medium-sized breed of dog used in hunting as a scenthound, usually in packs. It is one of the Anglo-French hound breeds which were created by crossing French scenthounds with English (Anglo) foxhounds. The name Petite Vénerie does not mean that dogs of the breed are petite or small, but rather that it is used to hunt small game.","The Appenzeller Sennenhund is a medium-size breed of dog, one of the four regional breeds of Sennenhund-type dogs from the Swiss Alps."];
    
    var dogImages: [String] = ["celldog1", "celldog2", "celldog3","celldog4","celldog5"];
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView!.estimatedRowHeight = 44
        tableView!.rowHeight = UITableViewAutomaticDimension
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated);
        
    
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       
        return dogDescriptions.count
            
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell{
            
        let cell = tableView.dequeueReusableCellWithIdentifier("dogCell", forIndexPath: indexPath) as! DogCell
        
        cell.dogDesc.text = dogDescriptions[indexPath.row]
        
        let image : UIImage = UIImage(named: dogImages[indexPath.row])!
            
        cell.dogImage.image = image
            
        return cell
     }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

