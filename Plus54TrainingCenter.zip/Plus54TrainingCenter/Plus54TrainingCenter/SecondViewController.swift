//
//  SecondViewController.swift
//  Plus54TrainingCenter
//
//  Created by matias on 6/25/15.
//  Copyright © 2015 Plus54. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
    
    var imgDog1: UIImageView!
    var imgDog2: UIImageView!
    var imgDog3: UIImageView!
    
    var dog1Center: NSLayoutConstraint!
    var dog2Center: NSLayoutConstraint!
    var dog3Center: NSLayoutConstraint!
    
    var compactConstraints: [NSLayoutConstraint]!
    
    var verticalConstraints: [NSLayoutConstraint]!
    var horizontalConstraints: [NSLayoutConstraint] = []
    var guideHeightConstraints: [NSLayoutConstraint] = []
    
    var sharedConstraints: [NSLayoutConstraint] = []
    var regularConstraints: [NSLayoutConstraint] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createDogViews()
        
        createConstraints()
        
        setUpGestures()
    }
    
    func createConstraints(){
    
        dogSizes()
        createCompactConstraints()
        createRegularConstraints()
        
        NSLayoutConstraint.activateConstraints(regularConstraints)
        NSLayoutConstraint.activateConstraints(sharedConstraints)
        view.layoutIfNeeded()
    
    }
    
    func dogSizes(){
        

        let widthConstraint: NSLayoutConstraint = imgDog1.widthAnchor.constraintEqualToAnchor(imgDog1.heightAnchor, multiplier: 1)
        
        let heightConstraint2: NSLayoutConstraint  = imgDog2.heightAnchor.constraintEqualToAnchor(imgDog1.heightAnchor, multiplier: 0.50)
        let widthConstraint2: NSLayoutConstraint  = imgDog2.widthAnchor.constraintEqualToAnchor(imgDog2.heightAnchor, multiplier:1)
        
        
        let heightConstraint3: NSLayoutConstraint  = imgDog3.heightAnchor.constraintEqualToAnchor(imgDog1.heightAnchor, multiplier: 0.50)
        let widthConstraint3: NSLayoutConstraint  = imgDog3.widthAnchor.constraintEqualToAnchor(imgDog3.heightAnchor, multiplier:1)
        
        NSLayoutConstraint.activateConstraints([widthConstraint, widthConstraint2, heightConstraint2, heightConstraint3, widthConstraint3])
    }
    
    func createRegularConstraints(){
        
        //ADD VERTICAL GUIDES
        let leadingDog1 = UILayoutGuide()
        leadingDog1.identifier =  "leadingDog1"
        view.addLayoutGuide(leadingDog1)
        
        let leadingDog2 = UILayoutGuide()
        leadingDog2.identifier =  "leadingDog2"
        view.addLayoutGuide(leadingDog2)
        
        let leadingDog3 = UILayoutGuide()
        leadingDog3.identifier =  "leadingDog3"
        view.addLayoutGuide(leadingDog3)
        
        let trailingDog1 = UILayoutGuide()
        trailingDog1.identifier =  "trailingDog1"
        view.addLayoutGuide(trailingDog1)
        
        let trailingDog2 = UILayoutGuide()
        trailingDog2.identifier =  "trailingDog2"
        view.addLayoutGuide(trailingDog2)
        
        let trailingDog3 = UILayoutGuide()
        trailingDog3.identifier =  "trailingDog3"
        view.addLayoutGuide(trailingDog3)
        
        let topLayoutGuide = self.topLayoutGuide;
        
        
        let views = ["imgDog1":imgDog1, "imgDog2":imgDog2, "imgDog3":imgDog3, "leadingDog1":leadingDog1, "leadingDog2":leadingDog2, "leadingDog3":leadingDog3, "trailingDog1":trailingDog1, "trailingDog2":trailingDog2, "trailingDog3":trailingDog3, "topLayoutGuide":topLayoutGuide]
        
        verticalConstraints = NSLayoutConstraint.constraintsWithVisualFormat("V:|[topLayoutGuide]-[imgDog1]-[imgDog2]-[imgDog3]-100-|", options: NSLayoutFormatOptions.AlignAllCenterX, metrics: nil, views:  views as! [String : AnyObject])
        
        sharedConstraints += verticalConstraints
       // NSLayoutConstraint.activateConstraints(verticalConstraints)
        
        
        //HORIZONTAL CONSTRAINTS
        func newHorizontalArray(layoutString:String, arrayID:NSString) -> Void {
            
            horizontalConstraints += NSLayoutConstraint.constraintsWithVisualFormat(layoutString, options: NSLayoutFormatOptions.AlignAllCenterY, metrics: nil, views: views as! [String : AnyObject])
            
        }
        
        newHorizontalArray("|[leadingDog1][imgDog1][trailingDog1]|", arrayID: "hDog1");
        newHorizontalArray("|[leadingDog2][imgDog2][trailingDog2]|", arrayID: "hDog2");
        newHorizontalArray("|[leadingDog3][imgDog3][trailingDog3]|", arrayID: "hDog3");
        
        sharedConstraints += horizontalConstraints
        //NSLayoutConstraint.activateConstraints(horizontalConstraints)
        
        
        //GUIDES SPACING BETWEEN DOGS
        func guideHeightToDogHeight(layoutGuide:UILayoutGuide, dog:UIImageView, identifier: String) -> NSLayoutConstraint {
            
            let guideHeightToDog: NSLayoutConstraint = layoutGuide.heightAnchor.constraintEqualToAnchor(dog.heightAnchor)
            guideHeightToDog.identifier = identifier;
            return guideHeightToDog;
        }
        
        guideHeightConstraints.append(guideHeightToDogHeight(leadingDog1, dog: imgDog1, identifier: "guideHeightToDog1"))
        guideHeightConstraints.append(guideHeightToDogHeight(leadingDog2, dog: imgDog2, identifier: "guideHeightToDog2"))
        guideHeightConstraints.append(guideHeightToDogHeight(leadingDog3, dog: imgDog3, identifier: "guideHeightToDog3"))
        
        sharedConstraints += guideHeightConstraints
        //NSLayoutConstraint.activateConstraints(sharedConstraints)
        
        
        
        //regular constraints
        let regularConstraints1: NSLayoutConstraint = leadingDog2.widthAnchor.constraintEqualToAnchor(trailingDog2.widthAnchor, multiplier: 0.2)
        let regularConstraints2: NSLayoutConstraint = leadingDog3.widthAnchor.constraintEqualToAnchor(trailingDog3.widthAnchor, multiplier: 0.2)
        
        //regularConstraints.append(leadingDog2.widthAnchor.constraintEqualToAnchor(trailingDog2.widthAnchor, multiplier: 0.2))
        //regularConstraints.append(leadingDog3.widthAnchor.constraintEqualToAnchor(trailingDog3.widthAnchor, multiplier: 0.2))
        regularConstraints = [regularConstraints1, regularConstraints2]
        
        
        //view.layoutIfNeeded()
    }

    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated);
        
        
    }
    
    func createDogViews() {
        /* Since 8 views are being created that have essentially identical setup code, just use a block to reduce code overhead.
        This could be also be done 'longhand' by setting up each planet with its own individual code, or in a separate method outside of this one rather than a block inside. */
        
        func dogCreate(dogName:String) -> UIImageView {
            
            let dog : UIImageView = UIImageView(image: UIImage(named:dogName))
            dog.translatesAutoresizingMaskIntoConstraints = false;
            dog.contentMode = UIViewContentMode.ScaleAspectFit;
            dog.accessibilityIdentifier = dogName;
            
            view.addSubview(dog)
            return dog
        }
        
        
        imgDog1 = dogCreate("celldog2");
        imgDog2 = dogCreate("celldog4");
        imgDog3 = dogCreate("celldog5");
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func createCompactConstraints(){

        //ALIGN CENTER X
        func createCenterXConstraint(dogToCenter:UIImageView, identifierName:String) -> NSLayoutConstraint {
            
            let newConstraint: NSLayoutConstraint = dogToCenter.centerXAnchor.constraintEqualToAnchor(self.view.centerXAnchor)
            newConstraint.identifier = identifierName;
            return newConstraint;
        }
        
        dog1Center = createCenterXConstraint(imgDog1, identifierName: "dog1")
        dog2Center = createCenterXConstraint(imgDog2, identifierName: "dog2")
        dog3Center = createCenterXConstraint(imgDog3, identifierName: "dog3")
        
        compactConstraints = [dog1Center, dog2Center, dog3Center]
        
        //NSLayoutConstraint.activateConstraints(centerConstraints)
    }
    
    func animateToCompact(){
    
    
    
    }
    
    func animateToRegular(){
        
        
    }
    
    func changeLayout(tapGesture: UITapGestureRecognizer) {
    
        if tapGesture.state == UIGestureRecognizerState.Ended {
            let regularConstraint: NSLayoutConstraint = regularConstraints.first!;
            let compactConstraint: NSLayoutConstraint = compactConstraints.first!;
            
            if (regularConstraint.active) {
                
                UIView.animateKeyframesWithDuration(1.5, delay: 0.0, options: UIViewKeyframeAnimationOptions.CalculationModeLinear, animations: {
                        self.animateToCompact()
                    }, completion:nil)
                
                
            }
            else if (compactConstraint.active) {
                
                UIView.animateKeyframesWithDuration(1.5, delay: 0.0, options: UIViewKeyframeAnimationOptions.CalculationModeLinear, animations: {
                    self.animateToRegular()
                    }, completion:nil)
            }
        }
    }
    
    
    func keyframeBasedLayoutChange(tapGesture: UITapGestureRecognizer) {
        /* When screen is double-tapped, toggle between layouts and animate the change using UIView animation. */
        
        if tapGesture.state == UIGestureRecognizerState.Ended {
            let regularConstraint: NSLayoutConstraint = regularConstraints.first!;
            let compactConstraint: NSLayoutConstraint = compactConstraints.first!;
            
            
            /*
            
            if (regularConstraint.active) {
                UIView.animateWithDuration(1.0, animations: {
                    NSLayoutConstraint.deactivateConstraints(self.view.constraints)
                    compactConstraint.active = true;
                    
                    self.view.layoutIfNeeded()
                })
                
            }else if (compactConstraint.active) {
                UIView.animateWithDuration(1.0, animations: {
                    
                    NSLayoutConstraint.deactivateConstraints(self.view.constraints)
                    regularConstraint.active = true;
                    self.view.layoutIfNeeded()
                })
            }*/
            

            if (regularConstraint.active) {
                UIView.animateWithDuration(1.0, animations: {
                    regularConstraint.active = false;
                    compactConstraint.active = true;
                    
                    self.view.layoutIfNeeded()
                })

            }else if (compactConstraint.active) {
                UIView.animateWithDuration(1.0, animations: {
                    regularConstraint.active = true;
                    compactConstraint.active = false;
                    self.view.layoutIfNeeded()
                })
            }
        }
        
    }
    //pragma mark - Gestures for animation
    
    func setUpGestures() {
    /* Double-tap will trigger the 'basic' layout animation. Double-tapping with two fingers (hold down option in the simulator to get multiple fingers) will trigger the keyframe animation. */

        let cSelector : Selector = "changeLayout:"
        let doubleTap = UITapGestureRecognizer(target: self, action: cSelector)
        doubleTap.numberOfTapsRequired = 2
        doubleTap.numberOfTouchesRequired = 1
        view.addGestureRecognizer(doubleTap)
        
        
        let cSelector2 : Selector = "keyframeBasedLayoutChange:"
        let twoFingerDoubleTap = UITapGestureRecognizer(target: self, action: cSelector2)
        twoFingerDoubleTap.numberOfTapsRequired = 2
        twoFingerDoubleTap.numberOfTouchesRequired = 2
        view.addGestureRecognizer(twoFingerDoubleTap)
        
    }
    
    
    
    
}

