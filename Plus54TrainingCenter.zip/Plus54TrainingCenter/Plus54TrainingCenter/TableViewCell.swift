//
//  TableViewCell.swift
//  Plus54TrainingCenter
//
//  Created by matias on 7/3/15.
//  Copyright © 2015 Plus54. All rights reserved.
//

import UIKit

class DogCell: UITableViewCell {
    
    @IBOutlet weak var dogImage: UIImageView!
    @IBOutlet weak var dogDesc: UILabel!
    
}
