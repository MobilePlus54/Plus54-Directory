//
//  FirstViewController.swift
//  Plus54TrainingCenter
//
//  Created by matias on 6/25/15.
//  Copyright © 2015 Plus54. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {

    @IBOutlet weak var verticalStackView: UIStackView!
    @IBOutlet weak var horizontalStackView: UIStackView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func addDog(sender: AnyObject) {
        let dogImgVw:UIImageView = UIImageView(image: UIImage(named: "dog"))
        dogImgVw.contentMode = .ScaleAspectFit
        self.horizontalStackView.addArrangedSubview(dogImgVw)
        UIView.animateWithDuration(0.25, animations: {
            self.horizontalStackView.layoutIfNeeded()
            self.verticalStackView.layoutIfNeeded()
        })
    }
    
    @IBAction func removeDog(sender: AnyObject) {
        let dogVw:UIView? = self.horizontalStackView.arrangedSubviews.last
        if let aDog = dogVw
        {
            self.horizontalStackView.removeArrangedSubview(aDog)
            aDog.removeFromSuperview()
            UIView.animateWithDuration(0.25, animations: {
                self.horizontalStackView.layoutIfNeeded()
            })
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

